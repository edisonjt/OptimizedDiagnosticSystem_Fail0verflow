/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espe.optimizeddiagnosticsystem.model;

import java.util.Date;

/**
 *
 * @author Jhonatan
 */
public class MedicalRecipe {
    String instructions;
    String nameOfPacient;
    Date date;
    String medications;
}
